@extends('layouts.main')


@section('content')
  
<h1>Home</h1>
<h2>Hello</h2>
<p>{{ $isi }}</p>
<img src="{{ $img1 }}" width="200px">



@endsection