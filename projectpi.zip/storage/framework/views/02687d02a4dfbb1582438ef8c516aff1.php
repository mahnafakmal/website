


<?php $__env->startSection('content'); ?>
  <h1>Kontak</h1>
  <h2>aaaa</h2>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH B:\TI 2\projectpi\resources\views/kontak.blade.php ENDPATH**/ ?>