


<?php $__env->startSection('content'); ?>
  <h1>Profile</h1>

  <h3><?php echo e($nama); ?></h3>
  <p><?php echo e($nohp); ?></p>
  <img src="<?php echo e($img); ?>" width="200px">


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TI 2\projectpi\resources\views/profile.blade.php ENDPATH**/ ?>