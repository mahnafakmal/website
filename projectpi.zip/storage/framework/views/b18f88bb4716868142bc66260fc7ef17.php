

<?php $__env->startSection('content'); ?>

    <h1>Edit Data Mahasiswa</h1>
    <div class="col-8 justify-content-senter"></div>
    <div class="card">
        
    <form action="/editdata/<?php echo e($data['id']); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
  <div class="mb-3">
    <label for="nama" class="form-label">Nama</label>
    <input type="text" name="name" value="<?php echo e($data['name']); ?>" placeholder="Nama Lengkap" class="form-control" >
   
  </div>
  <div class="mb-3">
    <label for="nim" class="form-label">Nomor Induk (Nim)</label>
    <input type="number" name="nim" value="<?php echo e($data['nim']); ?>" placeholder="Nomor Induk Mahasiswa" class="form-control" >

  </div>
  <div class="mb-3">
    <label for="prodi" class="form-label">Program Studi (Prodi)</label>
    <input type="text" name="prodi" value="<?php echo e($data['prodi']); ?>" placeholder="Program Studi" class="form-control" >
  </div>
  <div class="mb-3">
    <label for="email" class="form-label">Email</label>
    <input type="email" name="email" value="<?php echo e($data['email']); ?>" placeholder="email" class="form-control" >
  </div>
  <div class="mb-3">
    <label for="nohp" class="form-label">Nomor Henpone (No HP)</label>
    <input type="number" name="nohp" value="<?php echo e($data['nohp']); ?>" placeholder="Nomor Handphone" class="form-control" >
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
     </div> 


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\projectpi\resources\views/edit.blade.php ENDPATH**/ ?>