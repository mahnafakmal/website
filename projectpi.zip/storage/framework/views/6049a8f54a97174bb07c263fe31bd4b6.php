


<?php $__env->startSection('content'); ?>
<h1>Profile</h1>
 <img src="<?php echo e($img); ?>" style="width:150px; border-radius:10px;">

  <h3><?php echo e($nama); ?></h3>
  <p><?php echo e($nohp); ?></p>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\projectpi\resources\views/profile.blade.php ENDPATH**/ ?>