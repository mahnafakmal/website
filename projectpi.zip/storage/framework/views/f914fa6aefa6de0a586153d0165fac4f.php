



<?php $__env->startSection('content'); ?>
  <h1>Berita</h1>

    <?php $__currentLoopData = $beritas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <article class="mt-5">
    <a href="/berita/<?php echo e($berita [ 'slug' ]); ?>"><h2><?php echo e($berita['judul']); ?>

    </h2></a>
    <h3><?php echo e($berita ['penulis' ]); ?></h3>
    <p><?php echo e($berita ['konten']); ?></p>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</article>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\projectpi\resources\views/berita.blade.php ENDPATH**/ ?>