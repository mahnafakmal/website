


<?php $__env->startSection('content'); ?>
  
<h1>Home</h1>
<h2>Helo</h2>
<p><?php echo e($isi); ?></p>
<img src="<?php echo e($img1); ?>" width="200px">



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH B:\TI 2\projectpi\resources\views/home.blade.php ENDPATH**/ ?>