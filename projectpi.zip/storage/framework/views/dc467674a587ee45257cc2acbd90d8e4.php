


<?php $__env->startSection('content'); ?>
  <h1>Data Mahasiswa</h1>
<table class="table">
  <thead>
    <tr>
      <th scope="col">No</th>
      <th scope="col">Nim</th>
      <th scope="col">Nama</th>
      <th scope="col">Prodi</th>
      <th scope="col">Email</th>
      <th scope="col">No.Hp</th>
      <th scope="col">Aksi</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>Budi Bso</td>
      <td></td>
      <td>@mdo</td>
    </tr>
   
  </tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH B:\TI 2\projectpi\resources\views/\mahasiswa.blade.php ENDPATH**/ ?>